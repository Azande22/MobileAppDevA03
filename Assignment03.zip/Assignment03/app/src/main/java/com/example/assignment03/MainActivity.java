package com.example.assignment03;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.*;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    int remainingFocusFruit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        TextView textView = findViewById(R.id.textView);


        String[] arr = new String[6];  //will hold all image names
        arr[0] = "Apples";
        arr[1] = "Lemons";
        arr[2] = "Mangoes";
        arr[3] = "Peaches";
        arr[4] = "Strawberries";
        arr[5] = "Tomatoes";


        //# of focus fruits user needs to find
        int numFocusFruits = (int) (Math.random() * 8) + 1;

        int apple = R.drawable.apple;
        int lemon = R.drawable.lemon;
        int mango = R.drawable.mango;
        int peach = R.drawable.peach;
        int strawberry = R.drawable.strawberry;
        int tomato = R.drawable.tomato;

        int fruits[] = new int[6];

        fruits[0] = apple;
        fruits[1] = lemon;
        fruits[2] = mango;
        fruits[3] = peach;
        fruits[4] = strawberry;
        fruits[5] = tomato;



        int focusFruitIndex = (int) (Math.random() * 6) + 1;
        focusFruitIndex--;
        String focusFruit = arr[focusFruitIndex];

        //Now focus fruit has been selected
        textView.setText("Find all " + focusFruit + "(" + numFocusFruits + ")");

        int[] pool = new int[25];

        for (int i = 0; i < numFocusFruits; i++) {
            pool[i] = fruits[focusFruitIndex];
        }

        //calculations for random amts of remaining fruit

        int numRemainingFruit = 25 - numFocusFruits;
        int fruitTypes = 5;

        double remainderSection1;
        remainderSection1 = numRemainingFruit / fruitTypes;
        Math.ceil(remainderSection1);  //round the number up.
        int goodRemainder1 = (int) remainderSection1;
        numRemainingFruit -= remainderSection1;
        fruitTypes--;

        double remainderSection2;
        remainderSection2 = numRemainingFruit / fruitTypes;
        Math.ceil(remainderSection1);  //round the number up.
        int goodRemainder2 = (int) remainderSection2;
        numRemainingFruit -= remainderSection1;
        fruitTypes--;

        double remainderSection3;
        remainderSection3 = numRemainingFruit / fruitTypes;
        Math.ceil(remainderSection1);  //round the number up.
        int goodRemainder3 = (int) remainderSection3;
        numRemainingFruit -= remainderSection1;
        fruitTypes--;

        double remainderSection4;
        remainderSection4 = numRemainingFruit / fruitTypes;
        Math.ceil(remainderSection1);  //round the number up.
        int goodRemainder4 = (int) remainderSection4;
        numRemainingFruit -= remainderSection1;
        fruitTypes--;

        int goodRemainder5 = 25 - numRemainingFruit;

    }
}